/* SH Global Shopping — client-side app (multi-page)
   - stores products, cart and orders in localStorage
   - language switch (en / zh)
   - admin add/delete products (password admin123)
   - search, category filtering, cart and checkout (COD)
   - domain: www.shglobalsells.co.ke (for header/footer)
*/

const DOMAIN = "www.shglobalsells.co.ke";
const ADMIN_PASS = "admin123";

/* ---------------- seed products ----------------
   Includes pineapple so search works. Images from Unsplash.
*/
const SEED_PRODUCTS = [
  { id:'p-pineapple', titleEN:'Pineapple (each)', titleZH:'菠萝（个）', brand:'FarmFresh', price:150, cat:'Fruits', img:'https://images.unsplash.com/photo-1502741338009-cac2772e18bc?q=80&w=1200&auto=format&fit=crop&ixlib=rb-4.0.3&s=1', sku:'FR-PINE-01', descEN:'Sweet ripe pineapple, each.', descZH:'甜熟菠萝，单个售卖。' },
  { id:'p-bananas', titleEN:'Bananas (1kg)', titleZH:'香蕉 (1公斤)', brand:'Tropico', price:120, cat:'Fruits', img:'https://images.unsplash.com/photo-1576402187878-974f70a6e1c3?q=80&w=1200&auto=format&fit=crop&ixlib=rb-4.0.3&s=2', sku:'FR-BANA-01', descEN:'Yellow bananas, per kg.', descZH:'黄色香蕉，按公斤出售。' },
  { id:'p-apples', titleEN:'Red Apples (1kg)', titleZH:'红苹果 (1公斤)', brand:'Orchard', price:300, cat:'Fruits', img:'https://images.unsplash.com/photo-1567306226416-28f0efdc88ce?q=80&w=1200&auto=format&fit=crop&ixlib=rb-4.0.3&s=3', sku:'FR-APP-01', descEN:'Crisp red apples, 1kg.', descZH:'脆甜红苹果，1公斤。' },
  { id:'p-tomatoes', titleEN:'Tomatoes (1kg)', titleZH:'西红柿 (1公斤)', brand:'VeggieHub', price:150, cat:'Vegetables', img:'https://images.unsplash.com/photo-1567306226416-28f0efdc88ce?q=80&w=1200&auto=format&fit=crop&ixlib=rb-4.0.3&s=3', sku:'VG-TOM-01', descEN:'Fresh tomatoes, juicy and ripe.', descZH:'新鲜西红柿，多汁成熟。' },
  { id:'p-kale', titleEN:'Kale bunch', titleZH:'羽衣甘蓝', brand:'GreenFields', price:120, cat:'Vegetables', img:'https://images.unsplash.com/photo-1544025162-d76694265947?q=80&w=1200&auto=format&fit=crop&ixlib=rb-4.0.3&s=4', sku:'VG-KALE-01', descEN:'Fresh kale bunch.', descZH:'新鲜羽衣甘蓝。' },
  { id:'p-noodles', titleEN:'Instant Noodles Pack', titleZH:'方便面', brand:'QuickBite', price:80, cat:'Packaged Food', img:'https://images.unsplash.com/photo-1604908177522-1b6d1a3f0a34?q=80&w=1200&auto=format&fit=crop&ixlib=rb-4.0.3&s=5', sku:'PF-NOD-01', descEN:'2-pack instant noodles.', descZH:'2包装方便面。' }
];

// storage keys
const KEY_PRODUCTS = 'sh_products_v1';
const KEY_CART = 'sh_cart_v1';
const KEY_ORDERS = 'sh_orders_v1';
const KEY_LANG = 'sh_lang_v1';
const KEY_BANNER = 'sh_banner_v1';

// state
let products = JSON.parse(localStorage.getItem(KEY_PRODUCTS) || 'null') || SEED_PRODUCTS.slice();
let cart = JSON.parse(localStorage.getItem(KEY_CART) || '{}');
let orders = JSON.parse(localStorage.getItem(KEY_ORDERS) || '[]');
let LANG = localStorage.getItem(KEY_LANG) || 'en';

// i18n strings used on elements with data-i18n
const I18N = {
  en: {
    tagline: 'Fresh produce & packaged foods — Delivery first, pay on delivery',
    hero_h1: 'Fresh fruits & vegetables — delivered to your door',
    hero_p: 'We offer all varieties of fruits, vegetables and packaged foods. Place your order, enter delivery details and pay on delivery.',
    shopnow: 'Shop Now', fruits:'Fruits', vegetables:'Vegetables',
    popular:'Popular items', howitworks:'How it works', select:'Select & add to cart', deliver:'Enter delivery details at checkout', pay:'Pay on delivery (Cash on Delivery)',
    categories:'Categories', items:'Items in category', cart:'Your Cart', checkout:'Proceed to Checkout', clear:'Clear Cart', myorders:'My Orders',
  },
  zh: {
    tagline: '新鲜果蔬与包装食品 — 先送货，货到付款',
    hero_h1: '新鲜水果与蔬菜 — 送货上门',
    hero_p: '我们提供各种水果、蔬菜和包装食品。下单并填写送货信息，货到付款。',
    shopnow: '立即购物', fruits:'水果', vegetables:'蔬菜',
    popular:'热门商品', howitworks:'操作流程', select:'选择并加入购物车', deliver:'在结账时填写送货信息', pay:'货到付款（Cash on Delivery）',
    categories:'分类', items:'分类下的商品', cart:'你的购物车', checkout:'前往结账', clear:'清空购物车', myorders:'我的订单',
  }
};

/* ---------------- utilities ---------------- */
function saveState(){
  localStorage.setItem(KEY_PRODUCTS, JSON.stringify(products));
  localStorage.setItem(KEY_CART, JSON.stringify(cart));
  localStorage.setItem(KEY_ORDERS, JSON.stringify(orders));
}
function formatKES(n){ return Number(n).toLocaleString(); }
function translateUI(){
  document.querySelectorAll('[data-i18n]').forEach(el=>{
    const key = el.getAttribute('data-i18n');
    if(I18N[LANG] && I18N[LANG][key]) el.textContent = I18N[LANG][key];
  });
  document.querySelectorAll('[data-local-placeholder]').forEach(el=>{
    const key = el.getAttribute('data-local-placeholder');
    if(I18N[LANG] && I18N[LANG][key]) el.placeholder = I18N[LANG][key];
  });
  // page-specific placeholders
  const searchBoxes = document.querySelectorAll('#search');
  searchBoxes.forEach(s=> s.placeholder = LANG==='zh' ? '搜索商品 (例如: 菠萝)' : 'Search products (e.g. pineapple)');
}

/* ---------------- product rendering ---------------- */
function productCardHtml(p){
  const title = LANG === 'zh' ? (p.titleZH || p.titleEN || p.title) : (p.titleEN || p.title);
  const desc = LANG === 'zh' ? (p.descZH || p.descEN || '') : (p.descEN || p.descZH || '');
  return `
    <div class="product" data-id="${p.id}">
      <img src="${p.img}" alt="${title}">
      <div class="title">${title}</div>
      <div class="price">KES ${formatKES(p.price)}</div>
      <div class="muted">${desc}</div>
      <div class="actions">
        <button class="btn" data-act="view" data-id="${p.id}">View</button>
        <button class="btn btn-primary" data-act="add" data-id="${p.id}">Add to cart</button>
      </div>
    </div>
  `;
}

function renderProductList(filterFn){
  const container = document.querySelectorAll('#product-list');
  container.forEach(c=>{
    let list = products.slice();
    if(filterFn) list = list.filter(filterFn);
    c.innerHTML = list.map(productCardHtml).join('');
  });
  // attach events
  document.querySelectorAll('[data-act="add"]').forEach(btn=>{
    btn.onclick = ()=> addToCart(btn.dataset.id, 1);
  });
  document.querySelectorAll('[data-act="view"]').forEach(btn=>{
    btn.onclick = ()=> openProductModal(btn.dataset.id);
  });
  updateCartCountUI();
}

/* ---------------- categories page behavior ---------------- */
function setupCategoryLinks(){
  document.querySelectorAll('.cat-card').forEach(el=>{
    el.onclick = (ev)=>{
      ev.preventDefault();
      const cat = el.getAttribute('data-cat');
      // go to categories page area and render list
      renderProductList(p=>p.cat === cat);
      window.scrollTo(0, document.body.scrollHeight/4);
    };
  });
}

/* ---------------- cart behavior ---------------- */
function addToCart(id, qty=1){
  if(!cart[id]) cart[id] = { qty:0 };
  cart[id].qty += qty;
  saveState();
  updateCartCountUI();
  alert(LANG==='zh' ? '已加入购物车' : 'Added to cart');
}
function updateCartCountUI(){
  const count = Object.values(cart).reduce((s,i)=>s + i.qty,0);
  document.querySelectorAll('#cart-count').forEach(el=> el.textContent = count);
  // on cart page render items
  const cartItemsContainer = document.getElementById('cart-items');
  if(cartItemsContainer){
    cartItemsContainer.innerHTML = '';
    let total = 0;
    for(const id in cart){
      const it = cart[id];
      const p = products.find(x=>x.id === id);
      if(!p) continue;
      total += it.qty * p.price;
      const node = document.createElement('div');
      node.className = 'cart-item';
      node.innerHTML = `
        <img src="${p.img}" alt="">
        <div style="flex:1">
          <div style="font-weight:700">${LANG==='zh'? (p.titleZH||p.titleEN) : (p.titleEN||p.title)}</div>
          <div class="muted">KES ${formatKES(p.price)} x ${it.qty}</div>
          <div style="margin-top:8px">
            <button class="btn" data-act="dec" data-id="${id}">-</button>
            <button class="btn" data-act="inc" data-id="${id}">+</button>
            <button class="btn" data-act="del" data-id="${id}">Remove</button>
          </div>
        </div>
      `;
      cartItemsContainer.appendChild(node);
    }
    document.getElementById('cart-total').textContent = formatKES(total);
    attachCartItemButtons();
  }
}
function attachCartItemButtons(){
  document.querySelectorAll('[data-act="inc"]').forEach(b=> b.onclick = ()=> { const id=b.dataset.id; cart[id].qty++; saveState(); updateCartCountUI(); });
  document.querySelectorAll('[data-act="dec"]').forEach(b=> b.onclick = ()=> { const id=b.dataset.id; cart[id].qty--; if(cart[id].qty<=0) delete cart[id]; saveState(); updateCartCountUI(); });
  document.querySelectorAll('[data-act="del"]').forEach(b=> b.onclick = ()=> { const id=b.dataset.id; delete cart[id]; saveState(); updateCartCountUI(); });
}

/* ---------------- product modal (basic) --------------- */
function openProductModal(id){
  const p = products.find(x=>x.id===id); if(!p) return alert('Not found');
  const title = LANG==='zh' ? (p.titleZH||p.titleEN) : (p.titleEN||p.titleZH);
  const desc = LANG==='zh' ? (p.descZH||p.descEN||'') : (p.descEN||p.descZH||'');
  const html = `${title}\n\n${desc}\n\nPrice: KES ${formatKES(p.price)}`;
  alert(html);
}

/* ---------------- checkout & orders ------------------ */
function proceedToCheckout(){
  // simple prompt flow (no payments)
  if(Object.keys(cart).length===0) return alert(LANG==='zh' ? '购物车为空' : 'Cart is empty');
  const name = prompt(LANG==='zh' ? '请输入收货人姓名' : 'Full name for delivery');
  if(!name) return alert(LANG==='zh' ? '姓名为必填' : 'Name required');
  const phone = prompt(LANG==='zh' ? '请输入联系电话 (例如 2547...)' : 'Phone (e.g. 2547...)');
  if(!phone) return alert(LANG==='zh' ? '电话为必填' : 'Phone required');
  const addr = prompt(LANG==='zh' ? '请输入送货地址' : 'Delivery address');
  if(!addr) return alert(LANG==='zh' ? '地址为必填' : 'Address required');

  // compute total
  let total = 0;
  for(const id in cart){ const p = products.find(x=>x.id===id); total += (p.price * cart[id].qty); }

  const order = {
    id: 'ORD-' + Date.now(),
    name, phone, address: addr,
    items: JSON.parse(JSON.stringify(cart)),
    total, status: 'pending',
    createdAt: new Date().toISOString()
  };
  orders.push(order);
  // clear cart
  cart = {};
  saveState();
  updateCartCountUI();
  localStorage.setItem(KEY_ORDERS, JSON.stringify(orders));
  alert(LANG==='zh' ? `订单已创建，订单号: ${order.id}` : `Order created — Order ID: ${order.id}\nWe will deliver and collect payment on delivery.`);
  // redirect to orders page if present
  if(location.pathname.endsWith('cart.html')) location.href = 'orders.html';
}

/* ---------------- admin ---------------- */
function initAdmin(){
  const form = document.getElementById('admin-form');
  const adminProducts = document.getElementById('admin-products');
  function renderAdminProducts(){
    adminProducts.innerHTML = products.map(p=>{
      const title = LANG==='zh' ? (p.titleZH||p.titleEN) : (p.titleEN||p.titleZH);
      return `<div style="padding:8px;border-bottom:1px solid #eee">
        <strong>${title}</strong> — KES ${formatKES(p.price)} <button class="btn" data-act="del" data-id="${p.id}">Delete</button>
      </div>`;
    }).join('');
    adminProducts.querySelectorAll('[data-act="del"]').forEach(btn=>{
      btn.onclick = ()=> {
        const id = btn.dataset.id;
        if(!confirm('Delete product?')) return;
        products = products.filter(x=>x.id !== id);
        saveState();
        renderAdminProducts();
      };
    });
  }
  if(form){
    form.onsubmit = (e)=>{
      e.preventDefault();
      const pass = document.getElementById('admin-pass').value;
      if(pass !== ADMIN_PASS){ alert('Wrong admin password'); return; }
      const p = {
        id: 'p-' + Date.now(),
        titleEN: document.getElementById('p-title').value,
        titleZH: document.getElementById('p-title-zh').value || document.getElementById('p-title').value,
        price: Number(document.getElementById('p-price').value),
        img: document.getElementById('p-img').value || 'https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?q=80&w=1200&auto=format&fit=crop&ixlib=rb-4.0.3&s=6',
        sku: document.getElementById('p-sku').value,
        cat: document.getElementById('p-cat').value,
        descEN: document.getElementById('p-desc').value,
        descZH: document.getElementById('p-desc-zh').value || document.getElementById('p-desc').value
      };
      products.unshift(p);
      saveState();
      renderAdminProducts();
      alert('Product added');
      form.reset();
    };
  }
  // banner
  const bannerInput = document.getElementById('banner-url');
  const saveBannerBtn = document.getElementById('save-banner');
  if(saveBannerBtn){
    saveBannerBtn.onclick = ()=>{
      const url = bannerInput.value.trim();
      if(!url) return alert('Enter image URL');
      localStorage.setItem(KEY_BANNER, url);
      alert('Banner saved. Reload homepage to see it.');
    };
  }
  renderAdminProducts();
}

/* ---------------- orders page ---------------- */
function renderOrders(){
  const out = document.getElementById('orders-list');
  if(!out) return;
  const list = orders.slice().reverse();
  if(list.length===0){
    out.innerHTML = `<div class="card">No orders yet.</div>`;
    return;
  }
  out.innerHTML = list.map(o=>{
    const itemsHtml = Object.keys(o.items || {}).map(id=>{
      const qty = o.items[id].qty;
      const p = products.find(x=>x.id === id) || { titleEN: id };
      const title = LANG==='zh' ? (p.titleZH||p.titleEN) : (p.titleEN||p.titleZH);
      return `<div>${title} x ${qty}</div>`;
    }).join('');
    return `<div class="card" style="padding:12px;margin-bottom:10px">
      <div><strong>Order:</strong> ${o.id}</div>
      <div><strong>Name:</strong> ${o.name}</div>
      <div><strong>Phone:</strong> ${o.phone}</div>
      <div><strong>Address:</strong> ${o.address}</div>
      <div><strong>Total:</strong> KES ${formatKES(o.total)}</div>
      <div><strong>Items:</strong> ${itemsHtml}</div>
      <div><strong>Status:</strong> ${o.status}</div>
      <div style="font-size:12px;color:#666">Created: ${new Date(o.createdAt).toLocaleString()}</div>
    </div>`;
  }).join('');
}

/* ---------------- search ---------------- */
function setupSearch(){
  document.querySelectorAll('#searchBtn').forEach(btn=>{
    btn.onclick = ()=>{
      const q = document.querySelector('#search').value.trim().toLowerCase();
      if(!q) return alert(LANG==='zh' ? '请输入搜索词' : 'Enter a search term');
      // search across products and show results on categories.html or this page
      const results = products.filter(p=>{
        const titleEN = (p.titleEN||'').toLowerCase();
        const titleZH = (p.titleZH||'').toLowerCase();
        const brand = (p.brand||'').toLowerCase();
        const sku = (p.sku||'').toLowerCase();
        return titleEN.includes(q) || titleZH.includes(q) || brand.includes(q) || sku.includes(q);
      });
      if(location.pathname.endsWith('categories.html')){
        renderProductList(p => results.includes(p));
      } else {
        // try to redirect to categories page with results
        localStorage.setItem('sh_search_results', JSON.stringify(results.map(r=>r.id)));
        location.href = 'categories.html';
      }
    };
  });
}

/* ---------------- init per page ---------------- */
(function init(){
  // show year
  document.querySelectorAll('#year').forEach(el=> el.textContent = new Date().getFullYear());

  // set language selects
  document.querySelectorAll('#lang').forEach(s=>{
    s.value = LANG;
    s.onchange = ()=>{
      LANG = s.value;
      localStorage.setItem(KEY_LANG, LANG);
      translateUI();
      // re-render lists
      renderProductList();
      renderOrders();
    };
  });
  translateUI();

  // banner
  const banner = localStorage.getItem(KEY_BANNER);
  if(banner && document.querySelector('.banner-img')) document.querySelector('.banner-img').src = banner;

  // when categories page loaded, if there's a saved search results, show them
  const savedResults = JSON.parse(localStorage.getItem('sh_search_results') || 'null');
  if(location.pathname.endsWith('categories.html') && savedResults){
    const list = products.filter(p=> savedResults.includes(p.id));
    const container = document.querySelector('#product-list');
    if(container) {
      container.innerHTML = list.map(productCardHtml).join('');
      document.removeEventListener('click', ()=>{}); // ensure events will be set
      document.querySelectorAll('[data-act="add"]').forEach(btn=> btn.onclick = ()=> addToCart(btn.dataset.id,1));
      document.querySelectorAll('[data-act="view"]').forEach(btn=> btn.onclick = ()=> openProductModal(btn.dataset.id));
    }
    localStorage.removeItem('sh_search_results');
  }

  // page-specific init
  if(location.pathname.endsWith('index.html') || location.pathname.endsWith('/') ){
    renderProductList();
    setupCategoryLinks();
  }
  if(location.pathname.endsWith('categories.html')){
    renderProductList();
    setupCategoryLinks();
  }
  if(location.pathname.endsWith('cart.html')){
    updateCartCountUI();
    updateCartCountUI(); // twice for safety
    document.getElementById('goto-checkout').onclick = proceedToCheckout;
    document.getElementById('clear-cart').onclick = ()=> { cart = {}; saveState(); updateCartCountUI(); };
  }
  if(location.pathname.endsWith('orders.html')){
    renderOrders();
  }
  if(location.pathname.endsWith('admin.html')){
    initAdmin();
  }

  setupSearch();
  updateCartCountUI();
})();
